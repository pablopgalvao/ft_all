#!/bin/sh
id -G --name $FT_USER | tr ' ' ',' | tr -d '\n'
