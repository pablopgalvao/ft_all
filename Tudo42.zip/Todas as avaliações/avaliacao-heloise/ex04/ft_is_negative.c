/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_is_negative.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hbezerra <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/20 14:27:25 by hbezerra          #+#    #+#             */
/*   Updated: 2024/08/21 11:59:00 by hbezerra         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include<unistd.h>

void	ft_is_negative(int n)
{
	char	positivo;
	char	negativo;

	negativo = 'N';
	positivo = 'P';
	if (n < 0)
		write (1, &negativo, 1);
	else
		write (1, &positivo, 1);
}
