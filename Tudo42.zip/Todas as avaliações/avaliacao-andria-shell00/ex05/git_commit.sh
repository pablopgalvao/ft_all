#?/bash/bin
git log --format="%H" -n5
