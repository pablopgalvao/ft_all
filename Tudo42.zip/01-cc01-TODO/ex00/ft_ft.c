#include <unistd.h>
#include <stdio.h>

void	ft_ft(int *nbr);

void	ft_ft(int *nbr)
{
	*nbr = 42;
	printf("Endereco (nbr): %p", nbr);
	printf("Valor (*nbr): %i", *nbr);
}

int	main(void)
{
	int qlqr;
	ft_ft(&qlqr);
}

