/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rush04.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: efetterm <efetterm@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/18 21:07:57 by danilode          #+#    #+#             */
/*   Updated: 2024/08/18 22:43:09 by pabperei         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putchar(char nome_da_variavel);

void	imprime_linha(int largura, char primeiro, char meio, char ultimo)
{
	int	posicao_da_linha;

	posicao_da_linha = 1;
	while (posicao_da_linha <= largura)
	{
		if (posicao_da_linha == 1)
		{
			ft_putchar(primeiro);
		}
		else if (posicao_da_linha == largura)
		{
			ft_putchar(ultimo);
		}
		else
		{
			ft_putchar(meio);
		}
		posicao_da_linha++;
	}
	write(1, "\n", 1);
}

void	imprime_quadrado_rush(int largura, int altura)
{
	if (largura >= 0 || altura >= 0)
	{
		int	posicao_da_linha;

		posicao_da_linha = 1;
		while (posicao_da_linha <= altura) 
		{
			if (posicao_da_linha == 1) 
			{
				imprime_linha(largura, 'A', 'B', 'C');
			} 
			else if (posicao_da_linha == altura)
			{
				imprime_linha(largura, 'C', 'B', 'A');
			}
			else 
			{
				imprime_linha(largura, 'B', ' ', 'B');
			}
		posicao_da_linha++;
		}
	}
}

void	rush(int x, int y)
{
	imprime_quadrado_rush(x, y);
}
