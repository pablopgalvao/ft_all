/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rush01.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: danilode <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/18 21:10:06 by danilode          #+#    #+#             */
/*   Updated: 2024/08/18 21:10:16 by danilode         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
void ft_putchar();

void imprimeLinha(int x, char primeiro, char meio, char ultimo) {
    int i = 1;
    while (i <= x) {
        if (i == 1) {
            ft_putchar(primeiro);
        } else if (i == x) {
            ft_putchar(ultimo);
        } else {
            ft_putchar(meio);
        }
        i++;
    }
    write(1, "\n", 1);
}

void imprime_quadrado_rush(int largura, int altura) {
    int i = 1;
    while (i <= altura) {
        if (i == 1) {
            imprimeLinha(largura, '/', '*', '\\');
        } else if (i == largura) {
            imprimeLinha(largura, '\\', '*', '/');
        } else {
            imprimeLinha(largura, '*', ' ', '*');
        }
        i++;
    }
}

void rush(int x, int y) 
{
    imprime_quadrado_rush(x,y);
}
