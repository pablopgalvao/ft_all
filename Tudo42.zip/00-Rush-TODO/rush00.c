/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rush00.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: danilode <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/18 21:09:42 by danilode          #+#    #+#             */
/*   Updated: 2024/08/18 21:09:54 by danilode         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putchar(char nome_da_variavel);

void	imprime_linha(int largura, char primeiro, char meio, char ultimo)
{
	int	i;

	i = 1;
	while (i <= largura)
	{
		if (i == 1)
		{
			ft_putchar(primeiro);
 	}	else if (i == largura)
		{
		ft_putchar(ultimo);
  }	else
		{
			ft_putchar(meio);
}
	i++;
	}
	write(1, "\n", 1);
}

void imprime_quadrado_rush(int largura, int altura) 
{
	int	i;

	i = 1;
	while (i <= altura)
{
        if (i == 1 || i == altura)
{
            imprime_linha(largura, 'o', '-', 'o');
        } else {
            imprime_linha(largura, '|', ' ', '|');
        }
        i++;
}
}

void    rush(int x, int y)
{
    imprime_quadrado_rush(x, y);
}
