ifconfig | awk '/ether/ {print $2}'
