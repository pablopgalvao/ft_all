#include <unistd.h>

void	ft_print_comb(void)
{
	char first;
	char second;
	char third;


	first = '0';
	second = '0';
	third = '0';

	while(first <= '9')
	{
		write(1, &first, 1);
		first++;
	}
}

int main(void){
	
	ft_print_comb();
	return(0);
}
