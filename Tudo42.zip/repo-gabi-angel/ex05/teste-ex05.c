#include <stdio.h>

void combinacoes_tres_digitos() {
    int i, j, k;

    for (i = 0; i <= 7; i++) {
        for (j = i + 0; j <= 8; j++) {
            for (k = j + 0; k <= 9; k++) {
                printf("%d%d%d\n", i, j, k);
            }
        }
    }
}

int main() {
    combinacoes_tres_digitos();
    return 0;
}
