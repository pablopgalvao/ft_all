#include <stdio.h>

void print_combinations_recursive(int n) {
    if (n == 100) {
        return;
    }
    printf("%02d ", n);
    print_combinations_recursive(n + 1);
}

int main() {
    print_combinations_recursive(0);
    return 0;
}
