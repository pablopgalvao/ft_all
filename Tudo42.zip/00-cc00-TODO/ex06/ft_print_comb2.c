#include <unistd.h>

//void	ft_print_comb2(void);

void	ft_print_comb2(void){
	char first;
	char second;

	first = '0';
	second = '0';

	// Se first for nemor ou igual a 9, second++
	if(second <= '9'){
		write(1, "0", 1);
		write(1, &second, 1);
		write(1, ", ", 1);
		second++;
	}
	//second++; 
}	

int	main(){
	ft_print_comb2();
	return (0);
}
