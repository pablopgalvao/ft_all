/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_reverse_alphabet.c                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pabperei <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/16 20:04:58 by pabperei          #+#    #+#             */
/*   Updated: 2024/08/18 15:36:24 by pabperei         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_print_reverse_alphabet(void)
{
	char	letra_alfabeto;

	letra_alfabeto = 'z';
	while (letra_alfabeto >= 'a')
	{
		write(1, &letra_alfabeto, 1);
		letra_alfabeto--;
	}
}
