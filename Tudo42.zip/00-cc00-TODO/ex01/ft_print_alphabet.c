/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_alphabet.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pabperei <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/16 19:38:17 by pabperei          #+#    #+#             */
/*   Updated: 2024/08/17 20:59:09 by pabperei         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_print_alphabet(void)
{
	char	letra_alfabeto;

	letra_alfabeto = 'a';
	while (letra_alfabeto <= 'z')
	{
		write(1, &letra_alfabeto, 1);
		letra_alfabeto++;
	}
}
