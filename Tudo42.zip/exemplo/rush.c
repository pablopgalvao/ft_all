#include <unistd.h>

void imprimeLinha(int largura, char primeiro, char meio, char ultimo) {
    int i = 1;
    while (i <= largura) {
        if (i == 1) {
            write(1, &primeiro, 1);
        } else if (i == largura) {
            write(1, &ultimo, 1);
        } else {
            write(1, &meio, 1);
        }
        i++;
    }
    write(1, "\n", 1);
}

void imprimeQuadradoRush00(int largura, int altura) {
    int i = 1;
    while (i <= altura) {
        if (i == 1 || i == altura) {
            imprimeLinha(largura, 'o', '-', 'o');
        } else {
            imprimeLinha(largura, '|', ' ', '|');
        }
        i++;
    }
}

void imprimeQuadradoRush01(int largura, int altura) {
    int i = 1;
    while (i <= altura) {
        if (i == 1) {
            imprimeLinha(largura, '/', '*', '\\');
        } else if (i == altura) {
            imprimeLinha(largura, '\\', '*', '/');
        } else {
            imprimeLinha(largura, '*', ' ', '*');
        }
        i++;
    }
}

void imprimeQuadradoRush02(int largura, int altura) {
    int i = 1;
    while (i <= altura) {
        if (i == 1) {
            imprimeLinha(largura, 'A', 'B', 'A');
        } else if (i == altura) {
            imprimeLinha(largura, 'C', 'B', 'C');
        } else {
            imprimeLinha(largura, 'B', ' ', 'B');
        }
        i++;
    }
}

void imprimeQuadradoRush03(int largura, int altura) {
    int i = 1;
    while (i <= altura) {
        if (i == 1 || i == altura) {
            imprimeLinha(largura, 'A', 'B', 'C');
        } else {
            imprimeLinha(largura, 'B', ' ', 'B');
        }
        i++;
    }
}

void imprimeQuadradoRush04(int largura, int altura) {
    if(largura >= 0 || altura >= 0){
        int i = 1;
    while (i <= altura) {
        if (i == 1) {
            imprimeLinha(largura, 'A', 'B', 'C');
        } else if (i == altura) {
            imprimeLinha(largura, 'C', 'B', 'A');
        } else {
            imprimeLinha(largura, 'B', ' ', 'B');
        }
        i++;
    }
    }
}

void imprimeTodosQuadrados(int largura, int altura) {
    // imprimeQuadradoRush00(largura, altura);
    // imprimeQuadradoRush01(largura, altura);
    // imprimeQuadradoRush02(largura, altura);
    // imprimeQuadradoRush03(largura, altura);
    imprimeQuadradoRush04(largura, altura);
}

int main() {
    imprimeTodosQuadrados(10,0);
    return 0;
}
